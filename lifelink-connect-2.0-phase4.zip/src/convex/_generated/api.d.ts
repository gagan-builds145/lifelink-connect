/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as admin from "../admin.js";
import type * as aiRegistry from "../aiRegistry.js";
import type * as allocation from "../allocation.js";
import type * as ambulances from "../ambulances.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as authGate from "../authGate.js";
import type * as camps from "../camps.js";
import type * as community from "../community.js";
import type * as contact from "../contact.js";
import type * as crons from "../crons.js";
import type * as demo from "../demo.js";
import type * as documents from "../documents.js";
import type * as donorFallback from "../donorFallback.js";
import type * as donorPrediction from "../donorPrediction.js";
import type * as donors from "../donors.js";
import type * as drones from "../drones.js";
import type * as forecasting from "../forecasting.js";
import type * as guardian from "../guardian.js";
import type * as guardianDocuments from "../guardianDocuments.js";
import type * as http from "../http.js";
import type * as integrations from "../integrations.js";
import type * as inventory from "../inventory.js";
import type * as lib_community from "../lib/community.js";
import type * as lib_helpers from "../lib/helpers.js";
import type * as lib_messaging from "../lib/messaging.js";
import type * as lib_mlClient from "../lib/mlClient.js";
import type * as lib_requestLifecycle from "../lib/requestLifecycle.js";
import type * as lib_stockWatch from "../lib/stockWatch.js";
import type * as lib_vault from "../lib/vault.js";
import type * as matching from "../matching.js";
import type * as ml from "../ml.js";
import type * as notifications from "../notifications.js";
import type * as notificationsQueue from "../notificationsQueue.js";
import type * as profiles from "../profiles.js";
import type * as requests from "../requests.js";
import type * as scan from "../scan.js";
import type * as security from "../security.js";
import type * as stats from "../stats.js";
import type * as users from "../users.js";
import type * as validators from "../validators.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  admin: typeof admin;
  aiRegistry: typeof aiRegistry;
  allocation: typeof allocation;
  ambulances: typeof ambulances;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  authGate: typeof authGate;
  camps: typeof camps;
  community: typeof community;
  contact: typeof contact;
  crons: typeof crons;
  demo: typeof demo;
  documents: typeof documents;
  donorFallback: typeof donorFallback;
  donorPrediction: typeof donorPrediction;
  donors: typeof donors;
  drones: typeof drones;
  forecasting: typeof forecasting;
  guardian: typeof guardian;
  guardianDocuments: typeof guardianDocuments;
  http: typeof http;
  integrations: typeof integrations;
  inventory: typeof inventory;
  "lib/community": typeof lib_community;
  "lib/helpers": typeof lib_helpers;
  "lib/messaging": typeof lib_messaging;
  "lib/mlClient": typeof lib_mlClient;
  "lib/requestLifecycle": typeof lib_requestLifecycle;
  "lib/stockWatch": typeof lib_stockWatch;
  "lib/vault": typeof lib_vault;
  matching: typeof matching;
  ml: typeof ml;
  notifications: typeof notifications;
  notificationsQueue: typeof notificationsQueue;
  profiles: typeof profiles;
  requests: typeof requests;
  scan: typeof scan;
  security: typeof security;
  stats: typeof stats;
  users: typeof users;
  validators: typeof validators;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
