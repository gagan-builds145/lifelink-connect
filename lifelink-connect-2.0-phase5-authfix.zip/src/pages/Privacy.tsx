import { SiteFooter } from "@/components/lifelink/SiteFooter";
import { SiteHeader } from "@/components/lifelink/SiteHeader";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ShieldCheck } from "lucide-react";
import { Link } from "react-router";

const sections = [
  {
    title: "1. What we collect",
    body: [
      "Account data: verified email address, display name and role. LifeLink uses passwordless email codes, so no password hash is stored by this application.",
      "Donor data: blood group, date of birth, phone, city/area, preferred donation center, availability, last recorded donation and privacy preferences. A precise address is stored for administration but is never shown publicly or to requestors.",
      "Requestor and patient data: requestor contact details, patient name/reference/age, hospital, clinical reason, required component and units, urgency, doctor details and any uploaded prescription or hospital document.",
      "Operational data: requests, status history, inventory batches, inventory movements, donations, camp registrations, notifications and audit events.",
    ],
  },
  {
    title: "2. Why we process it",
    body: [
      "To verify eligibility of requesting accounts and staff organizations, coordinate blood requests, maintain an accurate shared inventory, record donations and camps, send workflow notifications, and keep the audit trail required for healthcare coordination.",
      "To protect the network: rate limiting, abuse prevention and security monitoring of sensitive endpoints.",
    ],
  },
  {
    title: "3. Who can see what",
    body: [
      "Public visitors see verified organization-level availability, city, official organization contacts and published camps. They do not see patient identity, prescriptions, donor contact details, donor addresses or staff accounts.",
      "Donors can see masked compatible request details. Contact details are shared with authorized Red Cross coordinators only when the donor opts in. Hospitals never receive donor contact details.",
      "Requestors see their own requests and status history. Hospitals see their own requests and requests assigned to them. Red Cross staff see requests, inventory and donor records needed for coordination, with actions attributed in the audit log.",
    ],
  },
  {
    title: "4. Documents and storage",
    body: [
      "Prescriptions and hospital documents are uploaded to managed file storage with private access. Access is checked server-side against the uploader, authorized Red Cross staff, or the hospital involved in the request.",
      "Only PDF, JPEG and PNG files up to 5 MB are accepted. File metadata is validated against the actual stored object before it can be attached to a request.",
    ],
  },
  {
    title: "5. Retention and deletion",
    body: [
      "This buildathon prototype does not automate legal retention periods. Before production use, define retention schedules with your legal and clinical governance teams, including deletion or de-identification of patient documents and donor records.",
      "You may request correction of inaccurate profile information. Blood group and organization identity changes require staff verification. Account deletion requests should be routed to the configured administrator contact.",
    ],
  },
  {
    title: "6. Security",
    body: [
      "Authentication is handled by Convex Auth with short-lived email verification codes and server-validated sessions. Role and organization authorization is enforced on the backend for every protected query and mutation.",
      "Inventory changes use transactional Convex mutations with explicit checks to prevent negative or oversold stock. Sensitive endpoints are rate limited. Audit events record the actor role and timestamp.",
      "No system is perfectly secure. Do not upload information that is not necessary for coordinating the request.",
    ],
  },
  {
    title: "7. Demo data",
    body: [
      "Sample organizations, requests, stock, camps and history are marked Demo Data throughout the interface. Demo Data is not live verified inventory and must not be used for clinical decisions. Keep it separate from production records.",
    ],
  },
  {
    title: "8. Contact",
    body: [
      "Privacy questions can be sent through the contact form on the homepage. The contact address is configured with VITE_LIFELINK_CONTACT_EMAIL; replace the placeholder before production use.",
    ],
  },
];

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-primary">
          <ShieldCheck className="size-3.5" />
          Privacy & data protection
        </div>
        <h1 className="mt-3 font-display text-[38px] font-extrabold leading-tight tracking-tight">
          Privacy policy
        </h1>
        <p className="mt-3 text-[13px] leading-6 text-muted-foreground">
          LifeLink handles sensitive healthcare coordination data. This policy explains what
          is stored, who can access it and how it is protected. It is a prototype policy and
          must be reviewed by qualified legal and clinical governance staff before production.
        </p>
        <Alert className="mt-6 border-amber-200 bg-amber-50/70">
          <AlertDescription className="text-[11.5px] leading-5 text-amber-900">
            <strong>Prototype notice:</strong> this deployment is a buildathon demonstration.
            Configure production retention, consent, breach response and data-processing
            agreements before handling real patient information.
          </AlertDescription>
        </Alert>

        <div className="mt-8 space-y-7">
          {sections.map((section) => (
            <section key={section.title}>
              <h2 className="text-[16px] font-bold tracking-tight">{section.title}</h2>
              <div className="mt-2 space-y-2">
                {section.body.map((paragraph) => (
                  <p key={paragraph} className="text-[12.5px] leading-6 text-muted-foreground">
                    {paragraph}
                  </p>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="mt-10 flex flex-wrap gap-3 border-t border-border pt-6 text-[12px]">
          <Link to="/terms" className="font-semibold text-primary hover:underline">Terms of use</Link>
          <Link to="/#contact" className="font-semibold text-primary hover:underline">Contact us</Link>
          <Link to="/" className="text-muted-foreground hover:text-primary">Back to home</Link>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
